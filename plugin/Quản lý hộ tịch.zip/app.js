/**
 * =============================================
 * Quản Lý Hộ Tịch - Main Application Logic
 * =============================================
 */

// ============ Global State ============
let appData = null;
let currentTab = 'dashboard';
let currentEditId = null;
let currentEditType = null;

const STORAGE_KEY = 'HO_TICH_DB_V1';

// ============ Storage Service ============
const StorageService = {
    save(data) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            // Simulate "Auto Save to Backup File" via console/toast for now in Web Enviroment
            console.log('✅ Auto-saved to LocalStorage');
            return true;
        } catch (e) {
            console.error('Save failed:', e);
            showToast('Lỗi lưu dữ liệu: ' + e.message, 'error');
            return false;
        }
    },

    load() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            return raw ? JSON.parse(raw) : null;
        } catch (e) {
            console.error('Load failed:', e);
            return null;
        }
    },

    clear() {
        localStorage.removeItem(STORAGE_KEY);
    },

    exportJSON(data) {
        const blob = new Blob([JSON.stringify(data, null, 4)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `backup_hotich_${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    },

    // Simple CSV Export for Cong Dan (Flat list)
    exportCSV(data) {
        if (!data || !data.cong_dan) return;

        const items = data.cong_dan;
        if (items.length === 0) {
            showToast('Không có dữ liệu công dân để xuất', 'warning');
            return;
        }

        // Define headers
        const headers = ["ID", "Họ Tên", "Giới Tính", "Ngày Sinh", "CCCD", "Thôn ID", "Địa Chỉ", "Trạng Thái"];

        // Map data
        const rows = items.map(cd => [
            cd.id,
            cd.ho_ten,
            cd.gioi_tinh,
            cd.ngay_sinh,
            cd.cccd || '',
            cd.thon_id,
            cd.dia_chi || '',
            cd.trang_thai
        ]);

        // Build CSV string (handle BOM for Excel UTF-8)
        const csvContent = "\uFEFF" + [
            headers.join(","),
            ...rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(","))
        ].join("\n");

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `cong_dan_${new Date().toISOString().slice(0, 10)}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    },

    // Import Logic is handled in event listeners
};

// ============ Initialization ============
document.addEventListener('DOMContentLoaded', async () => {
    initNavigation();
    bindGlobalEvents();
    if (typeof initEventListeners === 'function') initEventListeners();

    // 1. Try Load from LocalStorage (Primary DB)
    const localData = StorageService.load();

    if (localData) {
        appData = localData;
        console.log('📂 Loaded data from LocalStorage');
        showToast('Đã tải dữ liệu từ bộ nhớ', 'success');
    } else {
        // 2. If empty, Load from Template/Backup JSON File
        console.log('📂 LocalStorage empty, fetching template...');
        try {
            const response = await fetch('data/ho-tich-data.json');
            if (!response.ok) throw new Error('Failed to load template');
            appData = await response.json();

            // 3. Auto-Save to LocalStorage immediately (Initialize DB)
            StorageService.save(appData);
            console.log('📂 Initialized LocalStorage from template');
            showToast('Khởi tạo dữ liệu mẫu thành công', 'success');
        } catch (error) {
            console.error(error);
            appData = { cong_dan: [], ho_khau: [], thon: [], khai_sinh: [], khai_tu: [], ket_hon: [], cai_chinh: [] };
            showToast('Không thể tải dữ liệu mẫu', 'error');
        }
    }

    // Render
    refreshTabData(currentTab);
});

function bindGlobalEvents() {
    // Import/Export Buttons
    document.getElementById('btnExport').onclick = () => {
        // Default to CSV Export for compatibility with "Xuất Excel" label behavior (but CSV format)
        // Or we could use the original exportToExcel function which is more tailored?
        // Let's use the original one for formatting, but ensure it saves data? No save needed for export.
        // But the user asked for CSV. The original exportToExcel DOES CSV.
        // So we can fallback to the original binding in initEventListeners, OR override here.
        // Let's use StorageService.exportCSV as a backup or specific action.
        // Actually, let's leave btnExport to the original initEventListeners (which calls exportToExcel).
        // I will commented out this override to respect the original better formatted one.
        // StorageService.exportCSV(appData);
        if (typeof exportToExcel === 'function') exportToExcel();
    };

    const btnBackup = document.getElementById('btnBackup');
    if (btnBackup) {
        btnBackup.onclick = () => {
            StorageService.exportJSON(appData);
        };
    }

    // Add specific Backup Button logic if needed, or put it in UI.
    // Let's add a "Backup JSON" button dynamically or handle "Load File" as Import.

    // const fileInput = document.getElementById('fileInput');

    // document.getElementById('btnLoadFile').onclick = () => {
    //     // Removed to avoid duplicate trigger with initEventListeners
    //     // fileInput.click();
    // };

    // fileInput.onchange = (e) => {
    //     // Removed: This logic is already in handleFileLoad assigned in initEventListeners
    // };
}

function parseCSVImport(csvText) {
    // Basic CSV Parser
    const lines = csvText.split('\n').map(l => l.trim()).filter(l => l);
    if (lines.length < 2) return;

    // Assume Header: ID, Name, Gender... matches Export
    // We will merge or append. Let's Append with new IDs to be safe? 
    // Or Replace? "load lại csv làm data" sounds like Replace or Merge.
    // Let's implement smart Merge (Update if ID exists, Add if not)

    const headers = lines[0].split(','); // Naive split
    // Better: use regex for CSV splitting which handles quotes.
    // For now, assuming simple CSV from our Export function.

    let count = 0;

    // We need a robust CSV parser for quotes.
    const parseLine = (text) => {
        const result = [];
        let cell = '';
        let inQuotes = false;
        for (let i = 0; i < text.length; i++) {
            const char = text[i];
            if (char === '"') {
                if (inQuotes && text[i + 1] === '"') { // Escaped quote
                    cell += '"';
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (char === ',' && !inQuotes) {
                result.push(cell);
                cell = '';
            } else {
                cell += char;
            }
        }
        result.push(cell);
        return result;
    }

    for (let i = 1; i < lines.length; i++) {
        const cols = parseLine(lines[i]);
        if (cols.length < 2) continue; // Invalid

        // Map columns based on Export order:
        // ID(0), Name(1), Gender(2), DOB(3), CCCD(4), Thon(5), Address(6), Status(7)
        const id = cols[0] || generateId('CD');
        const newItem = {
            id: id,
            ho_ten: cols[1],
            gioi_tinh: cols[2],
            ngay_sinh: cols[3],
            cccd: cols[4],
            thon_id: cols[5],
            dia_chi: cols[6],
            trang_thai: cols[7] || 'Đang sống'
        };

        // Check exist
        const idx = appData.cong_dan.findIndex(c => c.id === newItem.id);
        if (idx >= 0) {
            appData.cong_dan[idx] = { ...appData.cong_dan[idx], ...newItem };
        } else {
            appData.cong_dan.push(newItem);
        }
        count++;
    }

    StorageService.save(appData);
    refreshTabData(currentTab);
    showToast(`Đã nhập ${count} công dân từ CSV`, 'success');
}

// ============ Utility Functions ============
function formatDate(dateStr) {
    if (!dateStr) return '-';
    // Handle CSV formats if needed, but assuming ISO from standard export
    const date = new Date(dateStr);
    return date.toLocaleDateString('vi-VN');
}

function generateId(prefix) {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 7);
    return `${prefix}${timestamp}${random}`.toUpperCase();
}

function getCongDanById(id) {
    return appData?.cong_dan?.find(cd => cd.id === id);
}

function getCongDanName(id) {
    const cd = getCongDanById(id);
    return cd ? cd.ho_ten : '-';
}

function getThonById(id) {
    return appData?.thon?.find(t => t.id === id);
}

function getThonName(id) {
    const thon = getThonById(id);
    return thon ? thon.ten : '-';
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type} show`;
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// ============ Modal Functions ============
function openModal(title, content) {
    const modal = document.getElementById('modal');
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = content;
    modal.classList.add('active');
}

function closeModal() {
    const modal = document.getElementById('modal');
    modal.classList.remove('active');
    currentEditId = null;
    currentEditType = null;
}

// ============ Tab Navigation ============
function initNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const tabId = item.dataset.tab;
            switchTab(tabId);
        });
    });
}

function switchTab(tabId) {
    // Update nav
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.tab === tabId);
    });

    // Update content
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.toggle('active', tab.id === `tab-${tabId}`);
    });

    currentTab = tabId;

    // Refresh data for the tab
    refreshTabData(tabId);
}

function refreshTabData(tabId) {
    switch (tabId) {
        case 'dashboard':
            renderDashboard();
            break;
        case 'cong-dan':
            renderCongDan();
            break;
        case 'ho-khau':
            renderHoKhau();
            break;
        case 'khai-sinh':
            renderKhaiSinh();
            break;
        case 'khai-tu':
            renderKhaiTu();
            break;
        case 'ket-hon':
            renderKetHon();
            break;
        case 'cai-chinh':
            renderCaiChinh();
            break;
        case 'thon':
            renderThon();
            break;
    }
}

// ============ Dashboard ============
function renderDashboard() {
    if (!appData) return;

    // Update stats
    document.getElementById('dashCongDan').textContent = appData.cong_dan?.length || 0;
    document.getElementById('dashHoKhau').textContent = appData.ho_khau?.length || 0;
    document.getElementById('dashKhaiSinh').textContent = appData.khai_sinh?.length || 0;
    document.getElementById('dashKetHon').textContent = appData.ket_hon?.length || 0;
    document.getElementById('dashKhaiTu').textContent = appData.khai_tu?.length || 0;
    document.getElementById('dashThon').textContent = appData.thon?.length || 0;

    // Quick stats in sidebar
    document.getElementById('statTotalCongDan').textContent = appData.cong_dan?.length || 0;
    document.getElementById('statTotalHoKhau').textContent = appData.ho_khau?.length || 0;

    // Render thon stats table
    const tbody = document.querySelector('#tableDashThon tbody');
    tbody.innerHTML = '';

    appData.thon?.forEach(thon => {
        const soHo = appData.ho_khau?.filter(hk => hk.thon_id === thon.id).length || 0;
        const danSo = appData.cong_dan?.filter(cd => cd.thon_id === thon.id).length || 0;

        tbody.innerHTML += `
            <tr>
                <td><strong>${thon.ten}</strong></td>
                <td>${thon.truong_thon}</td>
                <td>${soHo}</td>
                <td>${danSo}</td>
            </tr>
        `;
    });
}

// ============ Công Dân ============
function renderCongDan() {
    if (!appData) return;

    // Populate filter dropdowns
    const filterThon = document.getElementById('filterThon');
    if (filterThon.options.length <= 1) {
        appData.thon?.forEach(thon => {
            filterThon.innerHTML += `<option value="${thon.id}">${thon.ten}</option>`;
        });
    }

    // Get filter values
    const searchTerm = document.getElementById('searchCongDan')?.value?.toLowerCase() || '';
    const thonFilter = document.getElementById('filterThon')?.value || '';
    const gioiTinhFilter = document.getElementById('filterGioiTinh')?.value || '';
    const trangThaiFilter = document.getElementById('filterTrangThai')?.value || '';

    // Filter data
    let filtered = appData.cong_dan || [];

    if (searchTerm) {
        filtered = filtered.filter(cd =>
            cd.ho_ten.toLowerCase().includes(searchTerm) ||
            (cd.cccd && cd.cccd.includes(searchTerm))
        );
    }
    if (thonFilter) {
        filtered = filtered.filter(cd => cd.thon_id === thonFilter);
    }
    if (gioiTinhFilter) {
        filtered = filtered.filter(cd => cd.gioi_tinh === gioiTinhFilter);
    }
    if (trangThaiFilter) {
        filtered = filtered.filter(cd => cd.trang_thai === trangThaiFilter);
    }

    // Render table
    const tbody = document.querySelector('#tableCongDan tbody');
    tbody.innerHTML = '';

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="empty-state">
                    <div class="empty-state-icon">📭</div>
                    <div class="empty-state-text">Không có dữ liệu</div>
                </td>
            </tr>
        `;
        return;
    }

    filtered.forEach(cd => {
        const statusClass = cd.trang_thai === 'Đang sống' ? 'badge-success' : 'badge-danger';
        tbody.innerHTML += `
            <tr>
                <td><code>${cd.id}</code></td>
                <td><strong>${cd.ho_ten}</strong></td>
                <td>${cd.gioi_tinh}</td>
                <td>${formatDate(cd.ngay_sinh)}</td>
                <td>${cd.cccd || '-'}</td>
                <td>${getThonName(cd.thon_id)}</td>
                <td><span class="badge ${statusClass}">${cd.trang_thai}</span></td>
                <td>
                    <div class="action-btns">
                        <button class="btn-action btn-view" onclick="viewCongDan('${cd.id}')" title="Xem">👁️</button>
                        <button class="btn-action btn-edit" onclick="editCongDan('${cd.id}')" title="Sửa">✏️</button>
                        <button class="btn-action btn-delete" onclick="deleteCongDan('${cd.id}')" title="Xóa">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    });
}

function viewCongDan(id) {
    const cd = getCongDanById(id);
    if (!cd) return;

    const content = `
        <div class="detail-grid">
            <div class="detail-item">
                <div class="detail-label">Mã công dân</div>
                <div class="detail-value">${cd.id}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Họ và tên</div>
                <div class="detail-value">${cd.ho_ten}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Giới tính</div>
                <div class="detail-value">${cd.gioi_tinh}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Ngày sinh</div>
                <div class="detail-value">${formatDate(cd.ngay_sinh)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">CCCD/CMND</div>
                <div class="detail-value">${cd.cccd || 'Chưa có'}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Dân tộc</div>
                <div class="detail-value">${cd.dan_toc}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Tôn giáo</div>
                <div class="detail-value">${cd.ton_giao || 'Không'}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Nghề nghiệp</div>
                <div class="detail-value">${cd.nghe_nghiep || '-'}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Thôn</div>
                <div class="detail-value">${getThonName(cd.thon_id)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Trạng thái</div>
                <div class="detail-value">${cd.trang_thai}</div>
            </div>
            <div class="detail-item detail-full">
                <div class="detail-label">Địa chỉ</div>
                <div class="detail-value">${cd.dia_chi}</div>
            </div>
        </div>
    `;

    openModal(`👤 Thông tin Công dân: ${cd.ho_ten}`, content);
    document.getElementById('modalSave').style.display = 'none';
}

function editCongDan(id) {
    const cd = id ? getCongDanById(id) : null;
    currentEditId = id;
    currentEditType = 'cong-dan';

    const thonOptions = appData.thon?.map(t =>
        `<option value="${t.id}" ${cd?.thon_id === t.id ? 'selected' : ''}>${t.ten}</option>`
    ).join('') || '';

    const content = `
        <form id="formCongDan">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Họ và tên *</label>
                    <input type="text" class="form-input" id="cdHoTen" value="${cd?.ho_ten || ''}" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Giới tính *</label>
                    <select class="form-select" id="cdGioiTinh" required>
                        <option value="Nam" ${cd?.gioi_tinh === 'Nam' ? 'selected' : ''}>Nam</option>
                        <option value="Nữ" ${cd?.gioi_tinh === 'Nữ' ? 'selected' : ''}>Nữ</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Ngày sinh *</label>
                    <input type="date" class="form-input" id="cdNgaySinh" value="${cd?.ngay_sinh || ''}" required>
                </div>
                <div class="form-group">
                    <label class="form-label">CCCD/CMND</label>
                    <input type="text" class="form-input" id="cdCCCD" value="${cd?.cccd || ''}">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Dân tộc</label>
                    <input type="text" class="form-input" id="cdDanToc" value="${cd?.dan_toc || 'Kinh'}">
                </div>
                <div class="form-group">
                    <label class="form-label">Tôn giáo</label>
                    <input type="text" class="form-input" id="cdTonGiao" value="${cd?.ton_giao || 'Không'}">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Nghề nghiệp</label>
                    <input type="text" class="form-input" id="cdNgheNghiep" value="${cd?.nghe_nghiep || ''}">
                </div>
                <div class="form-group">
                    <label class="form-label">Thôn *</label>
                    <div style="display:flex; gap:5px;">
                        <select class="form-select" id="cdThon" required style="flex:1">
                            <option value="">-- Chọn thôn --</option>
                            ${thonOptions}
                        </select>
                        <button type="button" class="btn btn-outline" style="padding:0 10px;" onclick="quickAddThon()" title="Thêm thôn mới">➕</button>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Địa chỉ</label>
                <input type="text" class="form-input" id="cdDiaChi" value="${cd?.dia_chi || ''}">
            </div>
            <div class="form-group">
                <label class="form-label">Trạng thái</label>
                <select class="form-select" id="cdTrangThai">
                    <option value="Đang sống" ${cd?.trang_thai === 'Đang sống' ? 'selected' : ''}>Đang sống</option>
                    <option value="Đã mất" ${cd?.trang_thai === 'Đã mất' ? 'selected' : ''}>Đã mất</option>
                </select>
            </div>
        </form>
    `;

    openModal(id ? `✏️ Sửa Công dân: ${cd.ho_ten}` : '➕ Thêm Công dân mới', content);
    document.getElementById('modalSave').style.display = 'inline-flex';
}

function saveCongDan() {
    const hoTen = document.getElementById('cdHoTen').value.trim();
    const gioiTinh = document.getElementById('cdGioiTinh').value;
    const ngaySinh = document.getElementById('cdNgaySinh').value;
    const cccd = document.getElementById('cdCCCD').value.trim();
    const danToc = document.getElementById('cdDanToc').value.trim() || 'Kinh';
    const tonGiao = document.getElementById('cdTonGiao').value.trim() || 'Không';
    const ngheNghiep = document.getElementById('cdNgheNghiep').value.trim();
    const thonId = document.getElementById('cdThon').value;
    const diaChi = document.getElementById('cdDiaChi').value.trim();
    const trangThai = document.getElementById('cdTrangThai').value;

    if (!hoTen || !gioiTinh || !ngaySinh || !thonId) {
        showToast('Vui lòng điền đầy đủ thông tin bắt buộc', 'error');
        return false;
    }

    if (currentEditId) {
        // Update existing
        const idx = appData.cong_dan.findIndex(cd => cd.id === currentEditId);
        if (idx !== -1) {
            appData.cong_dan[idx] = {
                ...appData.cong_dan[idx],
                ho_ten: hoTen,
                gioi_tinh: gioiTinh,
                ngay_sinh: ngaySinh,
                cccd: cccd,
                dan_toc: danToc,
                ton_giao: tonGiao,
                nghe_nghiep: ngheNghiep,
                thon_id: thonId,
                dia_chi: diaChi,
                trang_thai: trangThai
            };
            showToast('Cập nhật thành công!', 'success');
        }
    } else {
        // Add new
        const newCd = {
            id: generateId('CD'),
            ho_ten: hoTen,
            gioi_tinh: gioiTinh,
            ngay_sinh: ngaySinh,
            cccd: cccd,
            dan_toc: danToc,
            ton_giao: tonGiao,
            nghe_nghiep: ngheNghiep,
            thon_id: thonId,
            dia_chi: diaChi,
            trang_thai: trangThai
        };
        appData.cong_dan.push(newCd);
        showToast('Thêm mới thành công!', 'success');
    }

    closeModal();
    renderCongDan();
    renderDashboard();
    StorageService.save(appData);
    return true;
}

function deleteCongDan(id) {
    const cd = getCongDanById(id);
    if (!cd) return;

    if (confirm(`Bạn có chắc muốn xóa công dân "${cd.ho_ten}"?`)) {
        appData.cong_dan = appData.cong_dan.filter(c => c.id !== id);
        showToast('Đã xóa công dân', 'success');
        StorageService.save(appData);
        renderCongDan();
        renderDashboard();
    }
}

function quickAddThon() {
    const tenThon = prompt("Nhập tên thôn mới:");
    if (!tenThon || !tenThon.trim()) return;

    const newId = generateId('T');

    // Check dupe name just in case
    const exists = appData.thon.find(t => t.ten.toLowerCase() === tenThon.trim().toLowerCase());
    if (exists) {
        showToast('Thôn này đã tồn tại!', 'error');
        return;
    }

    const newThon = {
        id: newId,
        ten: tenThon.trim(),
        truong_thon: "Chưa cập nhật",
        so_dien_thoai: ""
    };

    appData.thon.push(newThon);
    StorageService.save(appData);

    // Update select box if exists
    const select = document.getElementById('cdThon');
    if (select) {
        const option = document.createElement('option');
        option.value = newId;
        option.text = newThon.ten;
        select.appendChild(option);
        select.value = newId; // Auto select
    }

    showToast(`Đã thêm thôn: ${tenThon}`, 'success');
}

// ============ Hộ Khẩu ============
function renderHoKhau() {
    if (!appData) return;

    // Populate filter
    const filterThon = document.getElementById('filterThonHK');
    if (filterThon.options.length <= 1) {
        appData.thon?.forEach(thon => {
            filterThon.innerHTML += `<option value="${thon.id}">${thon.ten}</option>`;
        });
    }

    const searchTerm = document.getElementById('searchHoKhau')?.value?.toLowerCase() || '';
    const thonFilter = document.getElementById('filterThonHK')?.value || '';

    let filtered = appData.ho_khau || [];

    if (searchTerm) {
        filtered = filtered.filter(hk => {
            const chuHo = getCongDanName(hk.chu_ho_id).toLowerCase();
            return hk.so_ho_khau.toLowerCase().includes(searchTerm) || chuHo.includes(searchTerm);
        });
    }
    if (thonFilter) {
        filtered = filtered.filter(hk => hk.thon_id === thonFilter);
    }

    const tbody = document.querySelector('#tableHoKhau tbody');
    tbody.innerHTML = '';

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr><td colspan="7" class="empty-state">
                <div class="empty-state-icon">🏠</div>
                <div class="empty-state-text">Không có dữ liệu</div>
            </td></tr>
        `;
        return;
    }

    filtered.forEach(hk => {
        const soThanhVien = Array.isArray(hk.thanh_vien) ? hk.thanh_vien.length : 0;
        tbody.innerHTML += `
            <tr>
                <td><code>${hk.so_ho_khau}</code></td>
                <td><strong>${getCongDanName(hk.chu_ho_id)}</strong></td>
                <td>${getThonName(hk.thon_id)}</td>
                <td>${hk.dia_chi}</td>
                <td>${hk.so_dien_thoai || '-'}</td>
                <td><span class="badge badge-info">${soThanhVien} người</span></td>
                <td>
                    <div class="action-btns">
                        <button class="btn-action btn-view" onclick="viewHoKhau('${hk.id}')" title="Xem">👁️</button>
                        <button class="btn-action btn-edit" onclick="editHoKhau('${hk.id}')" title="Sửa">✏️</button>
                        <button class="btn-action btn-print" onclick="printHoKhau('${hk.id}')" title="In">🖨️</button>
                        <button class="btn-action btn-edit" onclick="exportHoKhauExcel('${hk.id}')" title="Xuất Excel">📊</button>
                        <button class="btn-action btn-delete" onclick="deleteHoKhau('${hk.id}')" title="Xóa">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    });
}

function viewHoKhau(id) {
    const hk = appData.ho_khau?.find(h => h.id === id);
    if (!hk) return;

    // Build member list with relationship
    let thanhVienRows = '';
    if (Array.isArray(hk.thanh_vien)) {
        hk.thanh_vien.forEach((tv, idx) => {
            const cdId = typeof tv === 'string' ? tv : tv.cong_dan_id;
            const quanHe = typeof tv === 'object' ? tv.quan_he : 'Thành viên';
            const cd = getCongDanById(cdId);
            if (cd) {
                const thongTinKhac = `CCCD: ${cd.cccd || 'Chưa có'}; Nghề: ${cd.nghe_nghiep || '-'}`;
                thanhVienRows += `
                    <tr>
                        <td>${idx + 1}</td>
                        <td><strong>${cd.ho_ten}</strong></td>
                        <td>${formatDate(cd.ngay_sinh)}</td>
                        <td>${cd.que_quan || '-'}</td>
                        <td>${quanHe}</td>
                        <td style="font-size:11px">${thongTinKhac}</td>
                    </tr>
                `;
            }
        });
    }

    const soThanhVien = Array.isArray(hk.thanh_vien) ? hk.thanh_vien.length : 0;

    const content = `
        <div class="detail-grid">
            <div class="detail-item">
                <div class="detail-label">Số hộ khẩu</div>
                <div class="detail-value">${hk.so_ho_khau}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Chủ hộ</div>
                <div class="detail-value">${getCongDanName(hk.chu_ho_id)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Thôn</div>
                <div class="detail-value">${getThonName(hk.thon_id)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Số điện thoại</div>
                <div class="detail-value">${hk.so_dien_thoai || '-'}</div>
            </div>
            <div class="detail-item detail-full">
                <div class="detail-label">Địa chỉ</div>
                <div class="detail-value">${hk.dia_chi}</div>
            </div>
        </div>
        <div style="margin-top:20px">
            <h4 style="margin-bottom:10px">📋 Danh sách thành viên (${soThanhVien} người)</h4>
            <table class="data-table" style="font-size:13px">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Họ và Tên</th>
                        <th>Ngày Sinh</th>
                        <th>Quê Quán</th>
                        <th>Quan Hệ</th>
                        <th>Thông Tin Khác</th>
                    </tr>
                </thead>
                <tbody>${thanhVienRows || '<tr><td colspan="6">Không có thành viên</td></tr>'}</tbody>
            </table>
        </div>
        <div style="margin-top:15px; display:flex; gap:10px;">
            <button class="btn btn-primary" onclick="printHoKhau('${hk.id}')">🖨️ In</button>
            <button class="btn btn-success" onclick="exportHoKhauExcel('${hk.id}')">📊 Xuất Excel</button>
        </div>
    `;

    openModal(`🏠 Hộ khẩu: ${hk.so_ho_khau}`, content);
    document.getElementById('modalSave').style.display = 'none';
}

function editHoKhau(id) {
    const hk = id ? appData.ho_khau?.find(h => h.id === id) : null;
    currentEditId = id;
    currentEditType = 'ho-khau';

    const thonOptions = appData.thon?.map(t =>
        `<option value="${t.id}" ${hk?.thon_id === t.id ? 'selected' : ''}>${t.ten}</option>`
    ).join('') || '';

    const congDanOptions = appData.cong_dan?.filter(cd => cd.trang_thai === 'Đang sống').map(cd =>
        `<option value="${cd.id}" ${hk?.chu_ho_id === cd.id ? 'selected' : ''}>${cd.ho_ten}</option>`
    ).join('') || '';

    // Build member list for editing
    let memberHtml = '';
    if (hk && Array.isArray(hk.thanh_vien)) {
        hk.thanh_vien.forEach((tv, idx) => {
            const cdId = typeof tv === 'string' ? tv : tv.cong_dan_id;
            const quanHe = typeof tv === 'object' ? tv.quan_he : 'Thành viên';
            const cd = getCongDanById(cdId);
            if (cd) {
                memberHtml += `
                    <div class="member-row" data-id="${cdId}" style="display:flex; gap:10px; align-items:center; margin-bottom:8px; padding:8px; background:#f9fafb; border-radius:6px;">
                        <span style="flex:1"><strong>${cd.ho_ten}</strong></span>
                        <select class="form-select member-quan-he" style="width:120px">
                            <option value="Chủ hộ" ${quanHe === 'Chủ hộ' ? 'selected' : ''}>Chủ hộ</option>
                            <option value="Vợ" ${quanHe === 'Vợ' ? 'selected' : ''}>Vợ</option>
                            <option value="Chồng" ${quanHe === 'Chồng' ? 'selected' : ''}>Chồng</option>
                            <option value="Con trai" ${quanHe === 'Con trai' ? 'selected' : ''}>Con trai</option>
                            <option value="Con gái" ${quanHe === 'Con gái' ? 'selected' : ''}>Con gái</option>
                            <option value="Bố" ${quanHe === 'Bố' ? 'selected' : ''}>Bố</option>
                            <option value="Mẹ" ${quanHe === 'Mẹ' ? 'selected' : ''}>Mẹ</option>
                            <option value="Anh" ${quanHe === 'Anh' ? 'selected' : ''}>Anh</option>
                            <option value="Chị" ${quanHe === 'Chị' ? 'selected' : ''}>Chị</option>
                            <option value="Em" ${quanHe === 'Em' ? 'selected' : ''}>Em</option>
                            <option value="Ông" ${quanHe === 'Ông' ? 'selected' : ''}>Ông</option>
                            <option value="Bà" ${quanHe === 'Bà' ? 'selected' : ''}>Bà</option>
                            <option value="Cháu" ${quanHe === 'Cháu' ? 'selected' : ''}>Cháu</option>
                            <option value="Khác" ${quanHe === 'Khác' ? 'selected' : ''}>Khác</option>
                        </select>
                        <button type="button" class="btn-action btn-delete" onclick="this.parentElement.remove()">🗑️</button>
                    </div>
                `;
            }
        });
    }

    const content = `
        <form id="formHoKhau">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Số hộ khẩu *</label>
                    <input type="text" class="form-input" id="hkSoHoKhau" value="${hk?.so_ho_khau || ''}" required placeholder="VD: PL003">
                </div>
                <div class="form-group">
                    <label class="form-label">Chủ hộ *</label>
                    <select class="form-select" id="hkChuHo" required>
                        <option value="">-- Chọn chủ hộ --</option>
                        ${congDanOptions}
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Thôn *</label>
                    <select class="form-select" id="hkThon" required>
                        <option value="">-- Chọn thôn --</option>
                        ${thonOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Số điện thoại</label>
                    <input type="text" class="form-input" id="hkSoDT" value="${hk?.so_dien_thoai || ''}">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Địa chỉ *</label>
                <input type="text" class="form-input" id="hkDiaChi" value="${hk?.dia_chi || ''}" required>
            </div>
            <div class="form-group">
                <label class="form-label">Ngày lập</label>
                <input type="date" class="form-input" id="hkNgayLap" value="${hk?.ngay_lap || new Date().toISOString().split('T')[0]}">
            </div>
            <hr style="margin: 20px 0; border-color: #e5e7eb;">
            <div class="form-group">
                <label class="form-label">👥 Thành viên hộ khẩu</label>
                <div id="memberList" style="max-height:200px; overflow-y:auto;">
                    ${memberHtml || '<p style="color:#6b7280; font-style:italic;">Chưa có thành viên</p>'}
                </div>
                <div style="margin-top:10px; display:flex; gap:10px;">
                    <select id="addMemberSelect" class="form-select" style="flex:1">
                        <option value="">-- Chọn công dân để thêm --</option>
                        ${congDanOptions}
                    </select>
                    <button type="button" class="btn btn-primary" onclick="addMemberToHoKhau()">➕ Thêm</button>
                </div>
            </div>
        </form>
    `;

    openModal(id ? `✏️ Sửa Hộ khẩu: ${hk.so_ho_khau}` : '➕ Thêm Hộ khẩu mới', content);
    document.getElementById('modalSave').style.display = 'inline-flex';
}

function addMemberToHoKhau() {
    const select = document.getElementById('addMemberSelect');
    const cdId = select.value;
    if (!cdId) {
        showToast('Vui lòng chọn công dân', 'warning');
        return;
    }

    const cd = getCongDanById(cdId);
    if (!cd) return;

    // Check if already exists
    const existing = document.querySelector(`#memberList .member-row[data-id="${cdId}"]`);
    if (existing) {
        showToast('Công dân đã có trong danh sách', 'warning');
        return;
    }

    // Remove placeholder text if exists
    const placeholder = document.querySelector('#memberList p');
    if (placeholder) placeholder.remove();

    const memberList = document.getElementById('memberList');
    const div = document.createElement('div');
    div.className = 'member-row';
    div.dataset.id = cdId;
    div.style.cssText = 'display:flex; gap:10px; align-items:center; margin-bottom:8px; padding:8px; background:#f9fafb; border-radius:6px;';
    div.innerHTML = `
        <span style="flex:1"><strong>${cd.ho_ten}</strong></span>
        <select class="form-select member-quan-he" style="width:120px">
            <option value="Thành viên">Thành viên</option>
            <option value="Chủ hộ">Chủ hộ</option>
            <option value="Vợ">Vợ</option>
            <option value="Chồng">Chồng</option>
            <option value="Con trai">Con trai</option>
            <option value="Con gái">Con gái</option>
            <option value="Bố">Bố</option>
            <option value="Mẹ">Mẹ</option>
            <option value="Anh">Anh</option>
            <option value="Chị">Chị</option>
            <option value="Em">Em</option>
            <option value="Ông">Ông</option>
            <option value="Bà">Bà</option>
            <option value="Cháu">Cháu</option>
            <option value="Khác">Khác</option>
        </select>
        <button type="button" class="btn-action btn-delete" onclick="this.parentElement.remove()">🗑️</button>
    `;
    memberList.appendChild(div);
    select.value = '';
    showToast(`Đã thêm ${cd.ho_ten}`, 'success');
}

function saveHoKhau() {
    const soHoKhau = document.getElementById('hkSoHoKhau').value.trim();
    const chuHoId = document.getElementById('hkChuHo').value;
    const thonId = document.getElementById('hkThon').value;
    const soDT = document.getElementById('hkSoDT').value.trim();
    const diaChi = document.getElementById('hkDiaChi').value.trim();
    const ngayLap = document.getElementById('hkNgayLap').value;

    if (!soHoKhau || !chuHoId || !thonId || !diaChi) {
        showToast('Vui lòng điền đầy đủ thông tin bắt buộc', 'error');
        return false;
    }

    // Collect members
    const memberRows = document.querySelectorAll('#memberList .member-row');
    const thanhVien = [];
    memberRows.forEach(row => {
        const cdId = row.dataset.id;
        const quanHe = row.querySelector('.member-quan-he').value;
        thanhVien.push({ cong_dan_id: cdId, quan_he: quanHe });
    });

    if (currentEditId) {
        // Update existing
        const idx = appData.ho_khau.findIndex(h => h.id === currentEditId);
        if (idx !== -1) {
            appData.ho_khau[idx] = {
                ...appData.ho_khau[idx],
                so_ho_khau: soHoKhau,
                chu_ho_id: chuHoId,
                thon_id: thonId,
                so_dien_thoai: soDT,
                dia_chi: diaChi,
                ngay_lap: ngayLap,
                thanh_vien: thanhVien
            };
            showToast('Cập nhật hộ khẩu thành công!', 'success');
        }
    } else {
        // Add new
        const newHk = {
            id: generateId('HK'),
            so_ho_khau: soHoKhau,
            chu_ho_id: chuHoId,
            thon_id: thonId,
            so_dien_thoai: soDT,
            dia_chi: diaChi,
            ngay_lap: ngayLap,
            thanh_vien: thanhVien
        };
        appData.ho_khau.push(newHk);
        showToast('Thêm hộ khẩu thành công!', 'success');
    }

    closeModal();
    renderHoKhau();
    renderDashboard();
    StorageService.save(appData);
    return true;
}

function deleteHoKhau(id) {
    const hk = appData.ho_khau?.find(h => h.id === id);
    if (!hk) return;

    if (confirm(`Bạn có chắc muốn xóa hộ khẩu "${hk.so_ho_khau}"?`)) {
        appData.ho_khau = appData.ho_khau.filter(h => h.id !== id);
        showToast('Đã xóa hộ khẩu', 'success');
        StorageService.save(appData);
        renderHoKhau();
        renderDashboard();
    }
}

// ============ Khai Sinh ============
function renderKhaiSinh() {
    if (!appData) return;

    const searchTerm = document.getElementById('searchKhaiSinh')?.value?.toLowerCase() || '';

    let filtered = appData.khai_sinh || [];

    if (searchTerm) {
        filtered = filtered.filter(ks => {
            const tenTre = getCongDanName(ks.cong_dan_id).toLowerCase();
            return ks.so_dang_ky.toLowerCase().includes(searchTerm) || tenTre.includes(searchTerm);
        });
    }

    const tbody = document.querySelector('#tableKhaiSinh tbody');
    tbody.innerHTML = '';

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr><td colspan="8" class="empty-state">
                <div class="empty-state-icon">🧒</div>
                <div class="empty-state-text">Không có dữ liệu</div>
            </td></tr>
        `;
        return;
    }

    filtered.forEach(ks => {
        const tre = getCongDanById(ks.cong_dan_id);
        tbody.innerHTML += `
            <tr>
                <td><code>${ks.so_dang_ky}</code></td>
                <td><strong>${getCongDanName(ks.cong_dan_id)}</strong></td>
                <td>${tre ? formatDate(tre.ngay_sinh) : '-'}</td>
                <td>${ks.noi_sinh}</td>
                <td>${getCongDanName(ks.cha_id)}</td>
                <td>${getCongDanName(ks.me_id)}</td>
                <td>${formatDate(ks.ngay_dang_ky)}</td>
                <td>
                    <div class="action-btns">
                        <button class="btn-action btn-view" onclick="viewKhaiSinh('${ks.id}')" title="Xem">👁️</button>
                        <button class="btn-action btn-edit" onclick="editKhaiSinh('${ks.id}')" title="Sửa">✏️</button>
                        <button class="btn-action btn-delete" onclick="deleteKhaiSinh('${ks.id}')" title="Xóa">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    });
}

function viewKhaiSinh(id) {
    const ks = appData.khai_sinh?.find(k => k.id === id);
    if (!ks) return;

    const tre = getCongDanById(ks.cong_dan_id);

    const content = `
        <div class="detail-grid">
            <div class="detail-item">
                <div class="detail-label">Số đăng ký</div>
                <div class="detail-value">${ks.so_dang_ky}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Ngày đăng ký</div>
                <div class="detail-value">${formatDate(ks.ngay_dang_ky)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Họ tên trẻ</div>
                <div class="detail-value">${getCongDanName(ks.cong_dan_id)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Ngày sinh</div>
                <div class="detail-value">${tre ? formatDate(tre.ngay_sinh) : '-'}</div>
            </div>
            <div class="detail-item detail-full">
                <div class="detail-label">Nơi sinh</div>
                <div class="detail-value">${ks.noi_sinh}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Cha</div>
                <div class="detail-value">${getCongDanName(ks.cha_id)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Mẹ</div>
                <div class="detail-value">${getCongDanName(ks.me_id)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Người khai</div>
                <div class="detail-value">${getCongDanName(ks.nguoi_khai)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Ghi chú</div>
                <div class="detail-value">${ks.ghi_chu || '-'}</div>
            </div>
        </div>
    `;

    openModal(`🧒 Giấy khai sinh: ${ks.so_dang_ky}`, content);
    document.getElementById('modalSave').style.display = 'none';
}

function editKhaiSinh(id) {
    const ks = id ? appData.khai_sinh?.find(k => k.id === id) : null;
    currentEditId = id;
    currentEditType = 'khai-sinh';

    const congDanOptions = appData.cong_dan?.map(cd =>
        `<option value="${cd.id}">${cd.ho_ten} (${formatDate(cd.ngay_sinh)})</option>`
    ).join('') || '';

    const content = `
        <form id="formKhaiSinh">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Số đăng ký *</label>
                    <input type="text" class="form-input" id="ksSoDangKy" value="${ks?.so_dang_ky || ''}" required placeholder="VD: 01/2026/KS">
                </div>
                <div class="form-group">
                    <label class="form-label">Ngày đăng ký *</label>
                    <input type="date" class="form-input" id="ksNgayDangKy" value="${ks?.ngay_dang_ky || new Date().toISOString().split('T')[0]}" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Trẻ được khai sinh *</label>
                <select class="form-select" id="ksCongDan" required>
                    <option value="">-- Chọn trẻ --</option>
                    ${congDanOptions}
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Nơi sinh *</label>
                <input type="text" class="form-input" id="ksNoiSinh" value="${ks?.noi_sinh || ''}" required placeholder="VD: Bệnh viện Đa khoa Quy Nhơn">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Cha</label>
                    <select class="form-select" id="ksCha">
                        <option value="">-- Chọn cha --</option>
                        ${congDanOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Mẹ</label>
                    <select class="form-select" id="ksMe">
                        <option value="">-- Chọn mẹ --</option>
                        ${congDanOptions}
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Người khai</label>
                <select class="form-select" id="ksNguoiKhai">
                    <option value="">-- Chọn người khai --</option>
                    ${congDanOptions}
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Ghi chú</label>
                <textarea class="form-textarea" id="ksGhiChu" rows="2">${ks?.ghi_chu || ''}</textarea>
            </div>
        </form>
    `;

    openModal(id ? `✏️ Sửa Khai sinh: ${ks.so_dang_ky}` : '➕ Thêm Khai sinh mới', content);
    document.getElementById('modalSave').style.display = 'inline-flex';

    // Set selected values after modal opens
    if (ks) {
        setTimeout(() => {
            document.getElementById('ksCongDan').value = ks.cong_dan_id || '';
            document.getElementById('ksCha').value = ks.cha_id || '';
            document.getElementById('ksMe').value = ks.me_id || '';
            document.getElementById('ksNguoiKhai').value = ks.nguoi_khai || '';
        }, 100);
    }
}

function saveKhaiSinh() {
    const soDangKy = document.getElementById('ksSoDangKy').value.trim();
    const ngayDangKy = document.getElementById('ksNgayDangKy').value;
    const congDanId = document.getElementById('ksCongDan').value;
    const noiSinh = document.getElementById('ksNoiSinh').value.trim();
    const chaId = document.getElementById('ksCha').value;
    const meId = document.getElementById('ksMe').value;
    const nguoiKhai = document.getElementById('ksNguoiKhai').value;
    const ghiChu = document.getElementById('ksGhiChu').value.trim();

    if (!soDangKy || !ngayDangKy || !congDanId || !noiSinh) {
        showToast('Vui lòng điền đầy đủ thông tin bắt buộc', 'error');
        return false;
    }

    if (currentEditId) {
        const idx = appData.khai_sinh.findIndex(k => k.id === currentEditId);
        if (idx !== -1) {
            appData.khai_sinh[idx] = {
                ...appData.khai_sinh[idx],
                so_dang_ky: soDangKy,
                ngay_dang_ky: ngayDangKy,
                cong_dan_id: congDanId,
                noi_sinh: noiSinh,
                cha_id: chaId,
                me_id: meId,
                nguoi_khai: nguoiKhai,
                ghi_chu: ghiChu
            };
            showToast('Cập nhật khai sinh thành công!', 'success');
        }
    } else {
        const newKs = {
            id: generateId('KS'),
            so_dang_ky: soDangKy,
            ngay_dang_ky: ngayDangKy,
            cong_dan_id: congDanId,
            noi_sinh: noiSinh,
            cha_id: chaId,
            me_id: meId,
            nguoi_khai: nguoiKhai,
            ghi_chu: ghiChu
        };
        appData.khai_sinh.push(newKs);
        showToast('Thêm khai sinh thành công!', 'success');
    }

    closeModal();
    renderKhaiSinh();
    renderDashboard();
    StorageService.save(appData);
    return true;
}

function deleteKhaiSinh(id) {
    if (confirm('Bạn có chắc muốn xóa giấy khai sinh này?')) {
        appData.khai_sinh = appData.khai_sinh.filter(k => k.id !== id);
        showToast('Đã xóa', 'success');
        renderKhaiSinh();
        StorageService.save(appData);
        renderDashboard();
    }
}

// ============ Khai Tử ============
function renderKhaiTu() {
    if (!appData) return;

    const searchTerm = document.getElementById('searchKhaiTu')?.value?.toLowerCase() || '';

    let filtered = appData.khai_tu || [];

    if (searchTerm) {
        filtered = filtered.filter(kt => {
            const ten = getCongDanName(kt.cong_dan_id).toLowerCase();
            return kt.so_dang_ky.toLowerCase().includes(searchTerm) || ten.includes(searchTerm);
        });
    }

    const tbody = document.querySelector('#tableKhaiTu tbody');
    tbody.innerHTML = '';

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr><td colspan="8" class="empty-state">
                <div class="empty-state-icon">⚰️</div>
                <div class="empty-state-text">Không có dữ liệu</div>
            </td></tr>
        `;
        return;
    }

    filtered.forEach(kt => {
        tbody.innerHTML += `
            <tr>
                <td><code>${kt.so_dang_ky}</code></td>
                <td><strong>${getCongDanName(kt.cong_dan_id)}</strong></td>
                <td>${formatDate(kt.ngay_mat)}</td>
                <td>${kt.noi_mat}</td>
                <td>${kt.nguyen_nhan}</td>
                <td>${getCongDanName(kt.nguoi_khai)}</td>
                <td>${formatDate(kt.ngay_dang_ky)}</td>
                <td>
                    <div class="action-btns">
                        <button class="btn-action btn-view" onclick="viewKhaiTu('${kt.id}')" title="Xem">👁️</button>
                        <button class="btn-action btn-delete" onclick="deleteKhaiTu('${kt.id}')" title="Xóa">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    });
}

function viewKhaiTu(id) {
    const kt = appData.khai_tu?.find(k => k.id === id);
    if (!kt) return;

    const content = `
        <div class="detail-grid">
            <div class="detail-item">
                <div class="detail-label">Số đăng ký</div>
                <div class="detail-value">${kt.so_dang_ky}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Ngày đăng ký</div>
                <div class="detail-value">${formatDate(kt.ngay_dang_ky)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Họ tên người mất</div>
                <div class="detail-value">${getCongDanName(kt.cong_dan_id)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Ngày mất</div>
                <div class="detail-value">${formatDate(kt.ngay_mat)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Nơi mất</div>
                <div class="detail-value">${kt.noi_mat}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Nguyên nhân</div>
                <div class="detail-value">${kt.nguyen_nhan}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Người khai</div>
                <div class="detail-value">${getCongDanName(kt.nguoi_khai)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Ghi chú</div>
                <div class="detail-value">${kt.ghi_chu || '-'}</div>
            </div>
        </div>
    `;

    openModal(`⚰️ Giấy khai tử: ${kt.so_dang_ky}`, content);
    document.getElementById('modalSave').style.display = 'none';
}

function deleteKhaiTu(id) {
    if (confirm('Bạn có chắc muốn xóa giấy khai tử này?')) {
        appData.khai_tu = appData.khai_tu.filter(k => k.id !== id);
        showToast('Đã xóa', 'success');
        renderKhaiTu();
        StorageService.save(appData);
        renderDashboard();
    }
}

function editKhaiTu(id) {
    const kt = id ? appData.khai_tu?.find(k => k.id === id) : null;
    currentEditId = id;
    currentEditType = 'khai-tu';

    const congDanOptions = appData.cong_dan?.map(cd =>
        `<option value="${cd.id}">${cd.ho_ten} (${formatDate(cd.ngay_sinh)})</option>`
    ).join('') || '';

    const content = `
        <form id="formKhaiTu">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Số đăng ký *</label>
                    <input type="text" class="form-input" id="ktSoDangKy" value="${kt?.so_dang_ky || ''}" required placeholder="VD: 01/2026/KT">
                </div>
                <div class="form-group">
                    <label class="form-label">Ngày đăng ký *</label>
                    <input type="date" class="form-input" id="ktNgayDangKy" value="${kt?.ngay_dang_ky || new Date().toISOString().split('T')[0]}" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Người mất *</label>
                <select class="form-select" id="ktCongDan" required>
                    <option value="">-- Chọn người mất --</option>
                    ${congDanOptions}
                </select>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Ngày mất *</label>
                    <input type="date" class="form-input" id="ktNgayMat" value="${kt?.ngay_mat || ''}" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Nơi mất *</label>
                    <input type="text" class="form-input" id="ktNoiMat" value="${kt?.noi_mat || ''}" required placeholder="VD: Tại nhà riêng">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Nguyên nhân *</label>
                <input type="text" class="form-input" id="ktNguyenNhan" value="${kt?.nguyen_nhan || ''}" required placeholder="VD: Bệnh tim">
            </div>
            <div class="form-group">
                <label class="form-label">Người khai</label>
                <select class="form-select" id="ktNguoiKhai">
                    <option value="">-- Chọn người khai --</option>
                    ${congDanOptions}
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Ghi chú</label>
                <textarea class="form-textarea" id="ktGhiChu" rows="2">${kt?.ghi_chu || ''}</textarea>
            </div>
        </form>
    `;

    openModal(id ? `✏️ Sửa Khai tử: ${kt.so_dang_ky}` : '➕ Thêm Khai tử mới', content);
    document.getElementById('modalSave').style.display = 'inline-flex';

    if (kt) {
        setTimeout(() => {
            document.getElementById('ktCongDan').value = kt.cong_dan_id || '';
            document.getElementById('ktNguoiKhai').value = kt.nguoi_khai || '';
        }, 100);
    }
}

function saveKhaiTu() {
    const soDangKy = document.getElementById('ktSoDangKy').value.trim();
    const ngayDangKy = document.getElementById('ktNgayDangKy').value;
    const congDanId = document.getElementById('ktCongDan').value;
    const ngayMat = document.getElementById('ktNgayMat').value;
    const noiMat = document.getElementById('ktNoiMat').value.trim();
    const nguyenNhan = document.getElementById('ktNguyenNhan').value.trim();
    const nguoiKhai = document.getElementById('ktNguoiKhai').value;
    const ghiChu = document.getElementById('ktGhiChu').value.trim();

    if (!soDangKy || !ngayDangKy || !congDanId || !ngayMat || !noiMat || !nguyenNhan) {
        showToast('Vui lòng điền đầy đủ thông tin bắt buộc', 'error');
        return false;
    }

    // Update citizen status to deceased
    const cdIdx = appData.cong_dan.findIndex(cd => cd.id === congDanId);
    if (cdIdx !== -1) {
        appData.cong_dan[cdIdx].trang_thai = 'Đã mất';
    }

    if (currentEditId) {
        const idx = appData.khai_tu.findIndex(k => k.id === currentEditId);
        if (idx !== -1) {
            appData.khai_tu[idx] = {
                ...appData.khai_tu[idx],
                so_dang_ky: soDangKy,
                ngay_dang_ky: ngayDangKy,
                cong_dan_id: congDanId,
                ngay_mat: ngayMat,
                noi_mat: noiMat,
                nguyen_nhan: nguyenNhan,
                nguoi_khai: nguoiKhai,
                ghi_chu: ghiChu
            };
            showToast('Cập nhật khai tử thành công!', 'success');
        }
    } else {
        const newKt = {
            id: generateId('KT'),
            so_dang_ky: soDangKy,
            ngay_dang_ky: ngayDangKy,
            cong_dan_id: congDanId,
            ngay_mat: ngayMat,
            noi_mat: noiMat,
            nguyen_nhan: nguyenNhan,
            nguoi_khai: nguoiKhai,
            ghi_chu: ghiChu
        };
        appData.khai_tu.push(newKt);
        showToast('Thêm khai tử thành công!', 'success');
    }

    closeModal();
    renderKhaiTu();
    renderCongDan();
    renderDashboard();
    StorageService.save(appData);
    return true;
}

// ============ Kết Hôn ============
function renderKetHon() {
    if (!appData) return;

    const searchTerm = document.getElementById('searchKetHon')?.value?.toLowerCase() || '';

    let filtered = appData.ket_hon || [];

    if (searchTerm) {
        filtered = filtered.filter(kh => {
            const chong = getCongDanName(kh.chong_id).toLowerCase();
            const vo = getCongDanName(kh.vo_id).toLowerCase();
            return kh.so_dang_ky.toLowerCase().includes(searchTerm) ||
                chong.includes(searchTerm) || vo.includes(searchTerm);
        });
    }

    const tbody = document.querySelector('#tableKetHon tbody');
    tbody.innerHTML = '';

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr><td colspan="7" class="empty-state">
                <div class="empty-state-icon">💍</div>
                <div class="empty-state-text">Không có dữ liệu</div>
            </td></tr>
        `;
        return;
    }

    filtered.forEach(kh => {
        tbody.innerHTML += `
            <tr>
                <td><code>${kh.so_dang_ky}</code></td>
                <td><strong>${getCongDanName(kh.chong_id)}</strong></td>
                <td><strong>${getCongDanName(kh.vo_id)}</strong></td>
                <td>${formatDate(kh.ngay_dang_ky)}</td>
                <td>${kh.noi_dang_ky}</td>
                <td>${kh.ghi_chu || '-'}</td>
                <td>
                    <div class="action-btns">
                        <button class="btn-action btn-view" onclick="viewKetHon('${kh.id}')" title="Xem">👁️</button>
                        <button class="btn-action btn-delete" onclick="deleteKetHon('${kh.id}')" title="Xóa">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    });
}

function viewKetHon(id) {
    const kh = appData.ket_hon?.find(k => k.id === id);
    if (!kh) return;

    const content = `
        <div class="detail-grid">
            <div class="detail-item">
                <div class="detail-label">Số đăng ký</div>
                <div class="detail-value">${kh.so_dang_ky}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Ngày đăng ký</div>
                <div class="detail-value">${formatDate(kh.ngay_dang_ky)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Chồng</div>
                <div class="detail-value">${getCongDanName(kh.chong_id)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Vợ</div>
                <div class="detail-value">${getCongDanName(kh.vo_id)}</div>
            </div>
            <div class="detail-item detail-full">
                <div class="detail-label">Nơi đăng ký</div>
                <div class="detail-value">${kh.noi_dang_ky}</div>
            </div>
            <div class="detail-item detail-full">
                <div class="detail-label">Ghi chú</div>
                <div class="detail-value">${kh.ghi_chu || '-'}</div>
            </div>
        </div>
    `;

    openModal(`💍 Giấy kết hôn: ${kh.so_dang_ky}`, content);
    document.getElementById('modalSave').style.display = 'none';
}

function deleteKetHon(id) {
    if (confirm('Bạn có chắc muốn xóa giấy kết hôn này?')) {
        appData.ket_hon = appData.ket_hon.filter(k => k.id !== id);
        showToast('Đã xóa', 'success');
        renderKetHon();
        StorageService.save(appData);
        renderDashboard();
    }
}

function editKetHon(id) {
    const kh = id ? appData.ket_hon?.find(k => k.id === id) : null;
    currentEditId = id;
    currentEditType = 'ket-hon';

    const congDanOptions = appData.cong_dan?.filter(cd => cd.trang_thai === 'Đang sống').map(cd =>
        `<option value="${cd.id}">${cd.ho_ten} (${cd.gioi_tinh}, ${formatDate(cd.ngay_sinh)})</option>`
    ).join('') || '';

    const content = `
        <form id="formKetHon">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Số đăng ký *</label>
                    <input type="text" class="form-input" id="khSoDangKy" value="${kh?.so_dang_ky || ''}" required placeholder="VD: 01/2026/KH">
                </div>
                <div class="form-group">
                    <label class="form-label">Ngày đăng ký *</label>
                    <input type="date" class="form-input" id="khNgayDangKy" value="${kh?.ngay_dang_ky || new Date().toISOString().split('T')[0]}" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Chồng *</label>
                    <select class="form-select" id="khChong" required>
                        <option value="">-- Chọn chồng --</option>
                        ${congDanOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Vợ *</label>
                    <select class="form-select" id="khVo" required>
                        <option value="">-- Chọn vợ --</option>
                        ${congDanOptions}
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Nơi đăng ký</label>
                <input type="text" class="form-input" id="khNoiDangKy" value="${kh?.noi_dang_ky || 'UBND xã Phước Sơn'}">
            </div>
            <div class="form-group">
                <label class="form-label">Ghi chú</label>
                <textarea class="form-textarea" id="khGhiChu" rows="2">${kh?.ghi_chu || ''}</textarea>
            </div>
        </form>
    `;

    openModal(id ? `✏️ Sửa Kết hôn: ${kh.so_dang_ky}` : '➕ Thêm Đăng ký Kết hôn mới', content);
    document.getElementById('modalSave').style.display = 'inline-flex';

    if (kh) {
        setTimeout(() => {
            document.getElementById('khChong').value = kh.chong_id || '';
            document.getElementById('khVo').value = kh.vo_id || '';
        }, 100);
    }
}

function saveKetHon() {
    const soDangKy = document.getElementById('khSoDangKy').value.trim();
    const ngayDangKy = document.getElementById('khNgayDangKy').value;
    const chongId = document.getElementById('khChong').value;
    const voId = document.getElementById('khVo').value;
    const noiDangKy = document.getElementById('khNoiDangKy').value.trim();
    const ghiChu = document.getElementById('khGhiChu').value.trim();

    if (!soDangKy || !ngayDangKy || !chongId || !voId) {
        showToast('Vui lòng điền đầy đủ thông tin bắt buộc', 'error');
        return false;
    }

    if (chongId === voId) {
        showToast('Chồng và vợ không thể là cùng một người', 'error');
        return false;
    }

    if (currentEditId) {
        const idx = appData.ket_hon.findIndex(k => k.id === currentEditId);
        if (idx !== -1) {
            appData.ket_hon[idx] = {
                ...appData.ket_hon[idx],
                so_dang_ky: soDangKy,
                ngay_dang_ky: ngayDangKy,
                chong_id: chongId,
                vo_id: voId,
                noi_dang_ky: noiDangKy,
                ghi_chu: ghiChu
            };
            showToast('Cập nhật kết hôn thành công!', 'success');
        }
    } else {
        const newKh = {
            id: generateId('KH'),
            so_dang_ky: soDangKy,
            ngay_dang_ky: ngayDangKy,
            chong_id: chongId,
            vo_id: voId,
            noi_dang_ky: noiDangKy,
            ghi_chu: ghiChu
        };
        appData.ket_hon.push(newKh);
        showToast('Thêm kết hôn thành công!', 'success');
    }

    closeModal();
    renderKetHon();
    renderDashboard();
    StorageService.save(appData);
    return true;
}

// ============ Cải Chính ============
function renderCaiChinh() {
    if (!appData) return;

    const tbody = document.querySelector('#tableCaiChinh tbody');
    tbody.innerHTML = '';

    const data = appData.thay_doi_cai_chinh || [];

    if (data.length === 0) {
        tbody.innerHTML = `
            <tr><td colspan="8" class="empty-state">
                <div class="empty-state-icon">📝</div>
                <div class="empty-state-text">Không có dữ liệu</div>
            </td></tr>
        `;
        return;
    }

    data.forEach(cc => {
        tbody.innerHTML += `
            <tr>
                <td><code>${cc.so_dang_ky}</code></td>
                <td><strong>${getCongDanName(cc.cong_dan_id)}</strong></td>
                <td><span class="badge badge-warning">${cc.loai}</span></td>
                <td>${cc.noi_dung_cu}</td>
                <td>${cc.noi_dung_moi}</td>
                <td>${cc.ly_do}</td>
                <td>${formatDate(cc.ngay_dang_ky)}</td>
                <td>
                    <div class="action-btns">
                        <button class="btn-action btn-view" onclick="viewCaiChinh('${cc.id}')" title="Xem">👁️</button>
                        <button class="btn-action btn-delete" onclick="deleteCaiChinh('${cc.id}')" title="Xóa">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    });
}

function viewCaiChinh(id) {
    const cc = appData.thay_doi_cai_chinh?.find(c => c.id === id);
    if (!cc) return;

    const content = `
        <div class="detail-grid">
            <div class="detail-item">
                <div class="detail-label">Số đăng ký</div>
                <div class="detail-value">${cc.so_dang_ky}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Ngày đăng ký</div>
                <div class="detail-value">${formatDate(cc.ngay_dang_ky)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Công dân</div>
                <div class="detail-value">${getCongDanName(cc.cong_dan_id)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Loại thay đổi</div>
                <div class="detail-value">${cc.loai}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Nội dung cũ</div>
                <div class="detail-value">${cc.noi_dung_cu}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Nội dung mới</div>
                <div class="detail-value">${cc.noi_dung_moi}</div>
            </div>
            <div class="detail-item detail-full">
                <div class="detail-label">Lý do</div>
                <div class="detail-value">${cc.ly_do}</div>
            </div>
            <div class="detail-item detail-full">
                <div class="detail-label">Ghi chú</div>
                <div class="detail-value">${cc.ghi_chu || '-'}</div>
            </div>
        </div>
    `;

    openModal(`📝 Cải chính: ${cc.so_dang_ky}`, content);
    document.getElementById('modalSave').style.display = 'none';
}

function deleteCaiChinh(id) {
    if (confirm('Bạn có chắc muốn xóa?')) {
        appData.thay_doi_cai_chinh = appData.thay_doi_cai_chinh.filter(c => c.id !== id);
        showToast('Đã xóa', 'success');
        StorageService.save(appData);
        renderCaiChinh();
    }
}

function editCaiChinh(id) {
    const cc = id ? appData.thay_doi_cai_chinh?.find(c => c.id === id) : null;
    currentEditId = id;
    currentEditType = 'cai-chinh';

    const congDanOptions = appData.cong_dan?.map(cd =>
        `<option value="${cd.id}">${cd.ho_ten}</option>`
    ).join('') || '';

    const loaiOptions = [
        'Cải chính họ tên',
        'Cải chính ngày sinh',
        'Cải chính giới tính',
        'Cải chính dân tộc',
        'Cải chính quốc tịch',
        'Thay đổi hộ tịch khác'
    ].map(loai => `<option value="${loai}" ${cc?.loai === loai ? 'selected' : ''}>${loai}</option>`).join('');

    const content = `
        <form id="formCaiChinh">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Số đăng ký *</label>
                    <input type="text" class="form-input" id="ccSoDangKy" value="${cc?.so_dang_ky || ''}" required placeholder="VD: 01/2026/CC">
                </div>
                <div class="form-group">
                    <label class="form-label">Ngày đăng ký *</label>
                    <input type="date" class="form-input" id="ccNgayDangKy" value="${cc?.ngay_dang_ky || new Date().toISOString().split('T')[0]}" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Công dân *</label>
                    <select class="form-select" id="ccCongDan" required>
                        <option value="">-- Chọn công dân --</option>
                        ${congDanOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Loại thay đổi *</label>
                    <select class="form-select" id="ccLoai" required>
                        <option value="">-- Chọn loại --</option>
                        ${loaiOptions}
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Nội dung cũ *</label>
                    <input type="text" class="form-input" id="ccNoiDungCu" value="${cc?.noi_dung_cu || ''}" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Nội dung mới *</label>
                    <input type="text" class="form-input" id="ccNoiDungMoi" value="${cc?.noi_dung_moi || ''}" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Lý do *</label>
                <input type="text" class="form-input" id="ccLyDo" value="${cc?.ly_do || ''}" required placeholder="VD: Sửa lỗi chính tả trong giấy khai sinh">
            </div>
            <div class="form-group">
                <label class="form-label">Ghi chú</label>
                <textarea class="form-textarea" id="ccGhiChu" rows="2">${cc?.ghi_chu || ''}</textarea>
            </div>
        </form>
    `;

    openModal(id ? `✏️ Sửa Cải chính: ${cc.so_dang_ky}` : '➕ Thêm Cải chính mới', content);
    document.getElementById('modalSave').style.display = 'inline-flex';

    if (cc) {
        setTimeout(() => {
            document.getElementById('ccCongDan').value = cc.cong_dan_id || '';
        }, 100);
    }
}

function saveCaiChinh() {
    const soDangKy = document.getElementById('ccSoDangKy').value.trim();
    const ngayDangKy = document.getElementById('ccNgayDangKy').value;
    const congDanId = document.getElementById('ccCongDan').value;
    const loai = document.getElementById('ccLoai').value;
    const noiDungCu = document.getElementById('ccNoiDungCu').value.trim();
    const noiDungMoi = document.getElementById('ccNoiDungMoi').value.trim();
    const lyDo = document.getElementById('ccLyDo').value.trim();
    const ghiChu = document.getElementById('ccGhiChu').value.trim();

    if (!soDangKy || !ngayDangKy || !congDanId || !loai || !noiDungCu || !noiDungMoi || !lyDo) {
        showToast('Vui lòng điền đầy đủ thông tin bắt buộc', 'error');
        return false;
    }

    if (currentEditId) {
        const idx = appData.thay_doi_cai_chinh.findIndex(c => c.id === currentEditId);
        if (idx !== -1) {
            appData.thay_doi_cai_chinh[idx] = {
                ...appData.thay_doi_cai_chinh[idx],
                so_dang_ky: soDangKy,
                ngay_dang_ky: ngayDangKy,
                cong_dan_id: congDanId,
                loai: loai,
                noi_dung_cu: noiDungCu,
                noi_dung_moi: noiDungMoi,
                ly_do: lyDo,
                ghi_chu: ghiChu
            };
            showToast('Cập nhật cải chính thành công!', 'success');
        }
    } else {
        const newCc = {
            id: generateId('CC'),
            so_dang_ky: soDangKy,
            ngay_dang_ky: ngayDangKy,
            cong_dan_id: congDanId,
            loai: loai,
            noi_dung_cu: noiDungCu,
            noi_dung_moi: noiDungMoi,
            ly_do: lyDo,
            ghi_chu: ghiChu
        };
        appData.thay_doi_cai_chinh.push(newCc);
        showToast('Thêm cải chính thành công!', 'success');
    }

    closeModal();
    renderCaiChinh();
    StorageService.save(appData);
    return true;
}

// ============ Thôn ============
function renderThon() {
    if (!appData) return;

    const tbody = document.querySelector('#tableThon tbody');
    tbody.innerHTML = '';

    appData.thon?.forEach(thon => {
        const soHo = appData.ho_khau?.filter(hk => hk.thon_id === thon.id).length || 0;
        const danSo = appData.cong_dan?.filter(cd => cd.thon_id === thon.id).length || 0;

        tbody.innerHTML += `
            <tr>
                <td><code>${thon.id}</code></td>
                <td><strong>${thon.ten}</strong></td>
                <td>${thon.truong_thon}</td>
                <td><span class="badge badge-info">${soHo} hộ</span></td>
                <td><span class="badge badge-success">${danSo} người</span></td>
                <td>
                    <div class="action-btns">
                        <button class="btn-action btn-edit" onclick="editThon('${thon.id}')" title="Sửa">✏️</button>
                        <button class="btn-action btn-delete" onclick="deleteThon('${thon.id}')" title="Xóa">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    });
}

function editThon(id) {
    const thon = id ? getThonById(id) : null;
    currentEditId = id;
    currentEditType = 'thon';

    const content = `
        <form id="formThon">
            <div class="form-group">
                <label class="form-label">Mã thôn *</label>
                <input type="text" class="form-input" id="thonMa" value="${thon?.id || ''}" ${id ? 'readonly style="background:#f3f4f6"' : 'required'} placeholder="VD: T05">
            </div>
            <div class="form-group">
                <label class="form-label">Tên thôn *</label>
                <input type="text" class="form-input" id="thonTen" value="${thon?.ten || ''}" required placeholder="VD: Thôn Phước Long">
            </div>
            <div class="form-group">
                <label class="form-label">Trưởng thôn *</label>
                <input type="text" class="form-input" id="thonTruongThon" value="${thon?.truong_thon || ''}" required placeholder="VD: Nguyễn Văn A">
            </div>
            <div class="form-group">
                <label class="form-label">Số điện thoại</label>
                <input type="text" class="form-input" id="thonSoDT" value="${thon?.so_dien_thoai || ''}" placeholder="VD: 0905123456">
            </div>
        </form>
    `;

    openModal(id ? `✏️ Sửa Thôn: ${thon.ten}` : '➕ Thêm Thôn mới', content);
    document.getElementById('modalSave').style.display = 'inline-flex';
}

function saveThon() {
    const thonMa = document.getElementById('thonMa').value.trim();
    const thonTen = document.getElementById('thonTen').value.trim();
    const truongThon = document.getElementById('thonTruongThon').value.trim();
    const soDT = document.getElementById('thonSoDT').value.trim();

    if (!thonMa || !thonTen || !truongThon) {
        showToast('Vui lòng điền đầy đủ thông tin bắt buộc', 'error');
        return false;
    }

    if (currentEditId) {
        const idx = appData.thon.findIndex(t => t.id === currentEditId);
        if (idx !== -1) {
            appData.thon[idx] = {
                ...appData.thon[idx],
                ten: thonTen,
                truong_thon: truongThon,
                so_dien_thoai: soDT
            };
            showToast('Cập nhật thôn thành công!', 'success');
        }
    } else {
        // Check duplicate ID
        if (appData.thon.some(t => t.id === thonMa)) {
            showToast('Mã thôn đã tồn tại', 'error');
            return false;
        }
        const newThon = {
            id: thonMa,
            ten: thonTen,
            truong_thon: truongThon,
            so_dien_thoai: soDT
        };
        appData.thon.push(newThon);
        showToast('Thêm thôn thành công!', 'success');
    }

    closeModal();
    renderThon();
    renderDashboard();
    StorageService.save(appData);
    return true;
}

function deleteThon(id) {
    const thon = getThonById(id);
    if (!thon) return;

    // Check if thon has residents
    const residents = appData.cong_dan?.filter(cd => cd.thon_id === id).length || 0;
    if (residents > 0) {
        showToast(`Không thể xóa thôn có ${residents} người đang cư trú`, 'error');
        return;
    }

    if (confirm(`Bạn có chắc muốn xóa "${thon.ten}"?`)) {
        appData.thon = appData.thon.filter(t => t.id !== id);
        showToast('Đã xóa thôn', 'success');
        renderThon();
        StorageService.save(appData);
        renderDashboard();
    }
}

// ============ File Operations ============
async function loadDefaultData() {
    try {
        const response = await fetch('data/ho-tich-data.json');
        if (response.ok) {
            appData = await response.json();
            showToast('Đã tải dữ liệu mẫu', 'success');
            renderDashboard();
        }
    } catch (error) {
        console.error('Error loading default data:', error);
        // Initialize empty data structure
        appData = {
            metadata: { version: "1.0", created: new Date().toISOString().split('T')[0] },
            thon: [],
            cong_dan: [],
            khai_sinh: [],
            khai_tu: [],
            ket_hon: [],
            ho_khau: [],
            thay_doi_cai_chinh: []
        };
    }
}

function loadFileFromDisk() {
    document.getElementById('fileInput').click();
}

function handleFileLoad(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const content = e.target.result;
            if (file.name.endsWith('.json')) {
                const parsed = JSON.parse(content);
                // Basic validation
                if (parsed && (parsed.cong_dan || parsed.metadata)) {
                    appData = parsed;
                    StorageService.save(appData);
                    showToast(`Đã tải JSON: ${file.name}`, 'success');
                    renderDashboard();
                    switchTab('dashboard');
                } else {
                    showToast('File JSON không đúng định dạng', 'error');
                }
            } else if (file.name.endsWith('.csv')) {
                if (typeof parseCSVImport === 'function') {
                    parseCSVImport(content); // This function handles saving and toast
                } else {
                    showToast('Lỗi: Hàm nhập CSV chưa được khởi tạo', 'error');
                }
            } else {
                showToast('Định dạng file không hỗ trợ', 'error');
            }
        } catch (error) {
            console.error(error);
            showToast('Lỗi đọc file: ' + error.message, 'error');
        }
    };
    reader.readAsText(file);
    event.target.value = ''; // Reset input
}

function exportToExcel() {
    if (!appData) {
        showToast('Chưa có dữ liệu để xuất', 'error');
        return;
    }

    // Create CSV content with BOM for Excel UTF-8
    let csv = '\uFEFF';

    // Export Công dân - Full list
    csv += 'DANH SÁCH CÔNG DÂN TOÀN XÃ\n';
    csv += 'STT,Mã,Họ tên,Giới tính,Ngày sinh,CCCD,Thôn,Địa chỉ,Quê quán,Số ĐT,Nghề nghiệp,Dân tộc,Tôn giáo,Trạng thái\n';

    appData.cong_dan?.forEach((cd, idx) => {
        csv += `${idx + 1},${cd.id},"${cd.ho_ten}",${cd.gioi_tinh},${formatDate(cd.ngay_sinh)},"${cd.cccd || ''}","${getThonName(cd.thon_id)}","${cd.dia_chi}","${cd.que_quan || ''}","${cd.so_dien_thoai || ''}","${cd.nghe_nghiep || ''}","${cd.dan_toc}","${cd.ton_giao}",${cd.trang_thai}\n`;
    });

    csv += '\n\n';

    // Export Hộ Khẩu - Full list
    csv += 'DANH SÁCH HỘ KHẨU TOÀN XÃ\n';
    csv += 'STT,Số hộ khẩu,Chủ hộ,Thôn,Địa chỉ,Số ĐT,Số thành viên,Ngày lập\n';

    appData.ho_khau?.forEach((hk, idx) => {
        const soTV = Array.isArray(hk.thanh_vien) ? hk.thanh_vien.length : 0;
        csv += `${idx + 1},${hk.so_ho_khau},"${getCongDanName(hk.chu_ho_id)}","${getThonName(hk.thon_id)}","${hk.dia_chi}","${hk.so_dien_thoai || ''}",${soTV},${formatDate(hk.ngay_lap)}\n`;
    });

    // Add export timestamp
    csv += `\nNgày xuất: ${new Date().toLocaleString('vi-VN')}\n`;

    // Download
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `ho-tich-toan-xa-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();

    showToast('Đã xuất file CSV toàn xã', 'success');
}

// Export single household to Excel (matching user's template)
function exportHoKhauExcel(id) {
    const hk = appData.ho_khau?.find(h => h.id === id);
    if (!hk) {
        showToast('Không tìm thấy hộ khẩu', 'error');
        return;
    }

    const chuHo = getCongDanById(hk.chu_ho_id);
    const soThanhVien = Array.isArray(hk.thanh_vien) ? hk.thanh_vien.length : 0;

    // Create CSV matching user's Excel template
    let csv = '\uFEFF'; // BOM for Excel UTF-8

    // Header: THÔNG TIN HỘ GIA ĐÌNH
    csv += 'THÔNG TIN HỘ GIA ĐÌNH\n';
    csv += `Chủ hộ:,"${chuHo?.ho_ten || '-'}"\n`;
    csv += `Địa chỉ:,"${hk.dia_chi}"\n`;
    csv += `Số điện thoại:,"${hk.so_dien_thoai || ''}"\n`;
    csv += `Số sổ hộ khẩu:,${hk.so_ho_khau}\n`;
    csv += `Số thành viên:,${soThanhVien}\n`;
    csv += '\n';

    // Member list header
    csv += 'DANH SÁCH THÀNH VIÊN\n';
    csv += 'STT,Họ và Tên,Ngày Sinh,Quê Quán,Quan Hệ,Thông Tin Khác\n';

    // Member rows
    if (Array.isArray(hk.thanh_vien)) {
        hk.thanh_vien.forEach((tv, idx) => {
            const cdId = typeof tv === 'string' ? tv : tv.cong_dan_id;
            const quanHe = typeof tv === 'object' ? tv.quan_he : 'Thành viên';
            const cd = getCongDanById(cdId);
            if (cd) {
                const thongTinKhac = `CCCD: ${cd.cccd || 'Chưa có'}; Nghề: ${cd.nghe_nghiep || '-'};`;
                csv += `${idx + 1},"${cd.ho_ten}",${formatDate(cd.ngay_sinh)},"${cd.que_quan || '-'}","${quanHe}","${thongTinKhac}"\n`;
            }
        });
    }

    // Export timestamp
    csv += `\nNgày xuất: ${new Date().toLocaleString('vi-VN')}\n`;

    // Download
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `ho-khau-${hk.so_ho_khau}-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();

    showToast(`Đã xuất hộ khẩu ${hk.so_ho_khau}`, 'success');
}

// Print household
function printHoKhau(id) {
    const hk = appData.ho_khau?.find(h => h.id === id);
    if (!hk) {
        showToast('Không tìm thấy hộ khẩu', 'error');
        return;
    }

    const chuHo = getCongDanById(hk.chu_ho_id);
    const soThanhVien = Array.isArray(hk.thanh_vien) ? hk.thanh_vien.length : 0;
    const diaPhuong = appData.metadata?.dia_phuong || {};

    // Build member table rows
    let memberRows = '';
    if (Array.isArray(hk.thanh_vien)) {
        hk.thanh_vien.forEach((tv, idx) => {
            const cdId = typeof tv === 'string' ? tv : tv.cong_dan_id;
            const quanHe = typeof tv === 'object' ? tv.quan_he : 'Thành viên';
            const cd = getCongDanById(cdId);
            if (cd) {
                const thongTinKhac = `CCCD: ${cd.cccd || 'Chưa có'}; Nghề: ${cd.nghe_nghiep || '-'};`;
                memberRows += `
                    <tr>
                        <td style="text-align:center">${idx + 1}</td>
                        <td>${cd.ho_ten}</td>
                        <td style="text-align:center">${formatDate(cd.ngay_sinh)}</td>
                        <td>${cd.que_quan || '-'}</td>
                        <td style="text-align:center">${quanHe}</td>
                        <td style="font-size:11px">${thongTinKhac}</td>
                    </tr>
                `;
            }
        });
    }

    // Create print window
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html lang="vi">
        <head>
            <meta charset="UTF-8">
            <title>Hộ khẩu ${hk.so_ho_khau}</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: 'Times New Roman', serif; padding: 20px; font-size: 14px; }
                .header { text-align: center; margin-bottom: 20px; }
                .header h1 { font-size: 18px; text-transform: uppercase; margin-bottom: 5px; }
                .header p { font-size: 12px; color: #555; }
                .section-title { 
                    background: #4a7c59; color: white; padding: 8px 12px; 
                    font-weight: bold; font-size: 14px; margin: 15px 0 10px 0;
                }
                .info-grid { display: grid; grid-template-columns: 150px 1fr; gap: 5px 10px; margin-bottom: 10px; }
                .info-label { font-weight: bold; color: #333; }
                .info-value { color: #000; }
                table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                th, td { border: 1px solid #333; padding: 6px 8px; text-align: left; }
                th { background: #f0f0f0; font-weight: bold; }
                .member-header { background: #ff9800; color: white; }
                .footer { margin-top: 20px; font-size: 11px; color: #666; text-align: right; }
                @media print {
                    body { padding: 0; }
                    .no-print { display: none; }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>UBND ${diaPhuong.xa || 'Xã'} - ${diaPhuong.huyen || 'Huyện'} - ${diaPhuong.tinh || 'Tỉnh'}</h1>
                <p>Trích lục thông tin hộ khẩu</p>
            </div>
            
            <div class="section-title">THÔNG TIN HỘ GIA ĐÌNH</div>
            <div class="info-grid">
                <span class="info-label">Chủ hộ:</span>
                <span class="info-value">${chuHo?.ho_ten || '-'}</span>
                <span class="info-label">Địa chỉ:</span>
                <span class="info-value">${hk.dia_chi}</span>
                <span class="info-label">Số điện thoại:</span>
                <span class="info-value">${hk.so_dien_thoai || '-'}</span>
                <span class="info-label">Số sổ hộ khẩu:</span>
                <span class="info-value">${hk.so_ho_khau}</span>
                <span class="info-label">Số thành viên:</span>
                <span class="info-value">${soThanhVien}</span>
            </div>
            
            <div class="section-title member-header">DANH SÁCH THÀNH VIÊN</div>
            <table>
                <thead>
                    <tr>
                        <th style="width:40px">STT</th>
                        <th>Họ và Tên</th>
                        <th style="width:100px">Ngày Sinh</th>
                        <th>Quê Quán</th>
                        <th style="width:80px">Quan Hệ</th>
                        <th>Thông Tin Khác</th>
                    </tr>
                </thead>
                <tbody>
                    ${memberRows || '<tr><td colspan="6" style="text-align:center">Không có thành viên</td></tr>'}
                </tbody>
            </table>
            
            <div class="footer">
                Ngày xuất: ${new Date().toLocaleString('vi-VN')}
            </div>
            
            <div class="no-print" style="margin-top: 20px; text-align: center;">
                <button onclick="window.print()" style="padding: 10px 30px; font-size: 16px; cursor: pointer;">🖨️ In</button>
                <button onclick="window.close()" style="padding: 10px 30px; font-size: 16px; cursor: pointer; margin-left: 10px;">✖️ Đóng</button>
            </div>
        </body>
        </html>
    `);
    printWindow.document.close();
}

// ============ About Kteam ============
function showAboutKteam() {
    const content = `
        <div style="text-align:center; padding: 10px 0;">
            <div style="font-size:4rem; margin-bottom:10px;">🎓</div>
            <h2 style="color:#2563eb; margin-bottom:5px; font-size:1.8rem;">Kteam</h2>
            <p style="color:#6b7280; margin-bottom:20px;">Phần mềm & Website tự động hóa chuyên sâu</p>
        </div>
        
        <div class="detail-grid" style="margin-top:20px;">
            <div class="detail-item">
                <div class="detail-label">🏢 Đội ngũ</div>
                <div class="detail-value">Kteam</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">💼 Chuyên môn</div>
                <div class="detail-value">Phần mềm & Website tự động hóa</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">🌐 Website</div>
                <div class="detail-value"><a href="https://howkteam.com/" target="_blank" style="color:#2563eb;">howkteam.com</a></div>
            </div>
            <div class="detail-item">
                <div class="detail-label">▶️ YouTube</div>
                <div class="detail-value"><a href="https://youtube.com/kteam" target="_blank" style="color:#2563eb;">youtube.com/kteam</a></div>
            </div>
            <div class="detail-item">
                <div class="detail-label">📘 Facebook</div>
                <div class="detail-value"><a href="https://facebook.com/rongk9vn" target="_blank" style="color:#2563eb;">facebook.com/rongk9vn</a></div>
            </div>
            <div class="detail-item">
                <div class="detail-label">📧 Email</div>
                <div class="detail-value"><a href="mailto:plus.kimlong@gmail.com" style="color:#2563eb;">plus.kimlong@gmail.com</a></div>
            </div>
        </div>
        
        <div style="margin-top:25px; padding:15px; background: linear-gradient(135deg, #eff6ff, #dbeafe); border-radius:12px; text-align:center;">
            <p style="color:#1e40af; font-style:italic; margin:0;">
                💬 "Chúng tôi tạo ra những công cụ giúp cuộc sống và công việc của bạn trở nên dễ dàng hơn"
            </p>
        </div>
        
        <div style="margin-top:15px; text-align:center; color:#9ca3af; font-size:12px;">
            © 2024-2026 Kteam. All rights reserved.
        </div>
    `;

    openModal('ℹ️ Thông tin Nhà phát triển', content);
    document.getElementById('modalSave').style.display = 'none';
}

// ============ Event Listeners ============
function initEventListeners() {
    // File input
    document.getElementById('btnLoadFile').addEventListener('click', loadFileFromDisk);
    document.getElementById('fileInput').addEventListener('change', handleFileLoad);

    // Export
    document.getElementById('btnExport').addEventListener('click', exportToExcel);

    // About Kteam
    document.getElementById('btnAbout')?.addEventListener('click', showAboutKteam);

    // Modal
    document.getElementById('modalClose').addEventListener('click', closeModal);
    document.getElementById('modalCancel').addEventListener('click', closeModal);
    document.getElementById('modalSave').addEventListener('click', handleModalSave);
    document.querySelector('.modal-overlay').addEventListener('click', closeModal);

    // Add buttons
    document.getElementById('btnAddCongDan')?.addEventListener('click', () => editCongDan(null));
    document.getElementById('btnAddHoKhau')?.addEventListener('click', () => editHoKhau(null));
    document.getElementById('btnAddKhaiSinh')?.addEventListener('click', () => editKhaiSinh(null));
    document.getElementById('btnAddKhaiTu')?.addEventListener('click', () => editKhaiTu(null));
    document.getElementById('btnAddKetHon')?.addEventListener('click', () => editKetHon(null));
    document.getElementById('btnAddCaiChinh')?.addEventListener('click', () => editCaiChinh(null));
    document.getElementById('btnAddThon')?.addEventListener('click', () => editThon(null));

    // Search filters
    document.getElementById('searchCongDan')?.addEventListener('input', renderCongDan);
    document.getElementById('filterThon')?.addEventListener('change', renderCongDan);
    document.getElementById('filterGioiTinh')?.addEventListener('change', renderCongDan);
    document.getElementById('filterTrangThai')?.addEventListener('change', renderCongDan);

    document.getElementById('searchHoKhau')?.addEventListener('input', renderHoKhau);
    document.getElementById('filterThonHK')?.addEventListener('change', renderHoKhau);

    document.getElementById('searchKhaiSinh')?.addEventListener('input', renderKhaiSinh);
    document.getElementById('searchKhaiTu')?.addEventListener('input', renderKhaiTu);
    document.getElementById('searchKetHon')?.addEventListener('input', renderKetHon);

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeModal();
    });
}

function handleModalSave() {
    switch (currentEditType) {
        case 'cong-dan':
            saveCongDan();
            break;
        case 'ho-khau':
            saveHoKhau();
            break;
        case 'khai-sinh':
            saveKhaiSinh();
            break;
        case 'khai-tu':
            saveKhaiTu();
            break;
        case 'ket-hon':
            saveKetHon();
            break;
        case 'cai-chinh':
            saveCaiChinh();
            break;
        case 'thon':
            saveThon();
            break;
        default:
            closeModal();
    }
}

// ============ Initialize ============
// Bottom initialization removed to avoid conflict with StorageService init
// document.addEventListener('DOMContentLoaded', async () => {
//     initNavigation();
//     initEventListeners();
//     await loadDefaultData();
// });
